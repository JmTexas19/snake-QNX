/* Variables header for application - AppBuilder 2.03  */

/* 'base' Window link */
const int ABN_base = 0;
const int ABN_snakeTimer = 1;
const int ABN_leftButton = 2;
const int ABN_newGameButton = 3;
const int ABN_upButton = 4;
const int ABN_rightButton = 5;
const int ABN_downButton = 6;
const int ABN_pauseButton = 7;
const int ABN_score = 8;
const int ABN_level = 9;
const int ABN_window = 10;
const int ABN_foodTimer = 11;

