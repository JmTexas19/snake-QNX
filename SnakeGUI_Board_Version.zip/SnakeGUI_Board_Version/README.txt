Snake Project SWENG452 Team 7

Importing sound files:
 1. Place mplayer in QNX VM root