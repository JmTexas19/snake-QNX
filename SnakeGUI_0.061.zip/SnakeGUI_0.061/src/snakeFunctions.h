/* snakeFunctions.c */
int snakeDirection;
int disableLeft;
int disableUp;
int disableRight;
int disableDown;